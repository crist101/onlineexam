from django.shortcuts import render
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.urls import reverse
from django.shortcuts import render
from .models import CourseTable,examStudentListTable,Users,examTable,QuestionTable,studentExamFormTable,studentAnswerKey
import datetime
from datetime import datetime
from asyncio.windows_events import NULL

def index(request):
    #if not request.user.is_authenticated:
    #    return HttpResponseRedirect(reverse("login"))
    #office = getoffice(request)
    #office = Group.objects.get(pk = office) 
    
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse(home))
    
    return render(request,"index.html")

def home(request):
    if request.method == "POST":
        #Add Course
        try:
            course = request.POST["course"]
            CourseTable.objects.create(course_name = course,course_date_created=datetime.now(),adviser = request.user)
            return HttpResponseRedirect(reverse("home"))
        except: 
            pass
        
        try:
            delete = request.POST["delete"] 
            val = request.POST["val"]
            course = CourseTable.objects.get(pk = val)
            course.delete()
            return HttpResponseRedirect(reverse("home"))
        except: 
            pass
        try:
            edit =  request.POST["edit"]
            val = request.POST["val"]
            course = CourseTable.objects.get(pk = val)
            course.course_name = request.POST["editcourse"]
            course.save()
            return HttpResponseRedirect(reverse("home"))
        except:
            pass
                
    course = CourseTable.objects.filter(adviser=request.user)
    return render(request,"course.html",{
        "course":course,
    })

def course(request,id):#Submitted form using POST method
    if request.method == "POST":
        record = CourseTable.objects.get(pk=id,adviser=request.user)
        datetimes = request.POST["datetimes"].split(" - ")
        start = datetime.strptime(datetimes[0], "%d/%m/%Y %H:%M:%S")
        end  = datetime.strptime(datetimes[1], "%d/%m/%Y %H:%M:%S")
        examTable.objects.create(course = record,exam_title=request.POST["exam_title"], exam_description = request.POST["exam_description"],startOfExam = start,endOfExam = end,exam_status = "Closed",date_created = datetime.now())
        return HttpResponseRedirect(reverse("course",args=[id]))
    #End of Submitted form using POST METHOD
    try:
        record = CourseTable.objects.get(pk=id,adviser=request.user)
        examform = examTable.objects.all().filter(course = record).exclude(exam_status = "Archived")
        student = Users.objects.all()
        return render(request,"courseform.html",{
            "record":record,
            "student":student,
            "examform":examform,
        })
    except:
        return HttpResponse("Record not found")

def courseUpdate(request,id):
    if request.method == "POST":
        try:
            examform = examTable.objects.get(pk=id)
            examform.exam_title = request.POST["exam_title"]
            examform.exam_description = request.POST["exam_description"]
            datetimes = request.POST["editdatetimes"].split(" - ")
            start = datetime.strptime(datetimes[0], "%d/%m/%Y %H:%M:%S")
            end  = datetime.strptime(datetimes[1], "%d/%m/%Y %H:%M:%S")
            examform.startOfExam = start
            examform.endOfExam = end
            examform.save()
            return HttpResponseRedirect(reverse("course",args=[examform.course.id]))
        except:
            return HttpResponse("Record not found")

def courseAction(request,id,examid):
    if request.method == "POST":
        try:
            if request.POST["delete"] == "delete":
                exam = examTable.objects.get(pk=examid)
                exam.delete()
                return HttpResponseRedirect(reverse("course",args=[id]))
        except:
            pass
        
        try:
            if request.POST["archived"] == "archived":
                exam = examTable.objects.get(pk=examid)
                exam.exam_status = "Archived"
                exam.save()
                return HttpResponseRedirect(reverse("course",args=[id]))
        except:
            pass
    else:
        return HttpResponse("404")

def courseArchived(request,id):
    try:
        record = CourseTable.objects.get(pk=id,adviser=request.user)
        examform = examTable.objects.all().filter(course = record,exam_status = "Archived")
        student = Users.objects.all()
        return render(request,"archived.html",{
            "record":record,
            "student":student,
            "examform":examform,
        })
    except:
        return HttpResponse("Record not found")
    
def courseRestore(request,id):
    try:
        if request.method == "POST":
            exam = examTable.objects.get(pk=id)
            exam.exam_status = "Closed"
            exam.save()
            return HttpResponseRedirect(reverse("courseArchived",args=[id]))
    except:
        return HttpResponse("Record not found")

def examForm(request,id,examid):
    try:
        record = CourseTable.objects.get(pk=id,adviser=request.user)
        exam = examTable.objects.get(pk = examid,course = record)
        if request.method == "POST":
            try:
                action = request.POST["action"]
                if action == "multiplechoice":
                    QuestionTable.objects.create(exam=exam,question=request.POST["question"],answer = request.POST["answer"],choice1=request.POST["choice1"],choice2=request.POST["choice2"],choice3=request.POST["choice3"],choice4=request.POST["choice4"],type="multiplechoice")
                elif action == "trueOrFalse":
                    QuestionTable.objects.create(exam=exam,question=request.POST["question"],answer = request.POST["answer"],type="trueorfalse")
                elif action == "identification":
                    QuestionTable.objects.create(exam=exam,question=request.POST["question"],answer = request.POST["answer"],type="identification")
                return HttpResponse("Success")
            except:
                return HttpResponse("Invalid")
        else:
            
            return render(request,"exam.html",{
                "record":record,
                "exam":exam,
            })
    except:
        return HttpResponse("Record not found")
    
def examFormResult(request,id,examid):
    #try:
    record = CourseTable.objects.get(pk=id,adviser=request.user)
    exam = examTable.objects.get(pk = examid,course = record) 
    list = studentExamFormTable.objects.filter(exam = exam)
    return render(request,"examResult.html",{
            "record":record,
            "exam":exam,
            "list":list
        })
    #except:
    #    return HttpResponse("Record not found")
    
def getAnswerSheet(request,examid):
    form = studentExamFormTable.objects.get(pk=examid)
    answerkey = studentAnswerKey.objects.filter(studentExamFormTable = form)
    questionkey = QuestionTable.objects.filter(exam = form.exam)
    item_ = []
    
    #New Proccess Code
    for item in questionkey:
        question = item.question.replace('"', "'")
        answer = item.answer
        try:
            itemKey = studentAnswerKey.objects.get(question = item, studentExamFormTable = form)
            a = item.choice1
            b = item.choice2
            c = item.choice3
            d = item.choice4
            item_.append([question,a,b,c,d,answer,itemKey.answer,item.type])
        except:
            item_.append([question,a,b,c,d,item.answer,"No Answer",item.type])
    #Old Code
    return JsonResponse(item_,safe=False)

def editForm(request):
    if request.method == "POST":
        question = QuestionTable.objects.get(pk = request.POST["id"])
        col = request.POST["col"]
        val = request.POST["val"]
        if(col == "question"):
            question.question = val
        elif(col == "answer"):
            question.answer = val
        elif(col == "choice1"):
            question.choice1 = val
        elif(col == "choice2"):
            question.choice2 = val
        elif(col == "choice3"):
            question.choice3 = val
        elif(col == "choice4"):
            question.choice4 = val
        question.save()
        return HttpResponse("Success")

def examFormList(request,id,examid,action):
    try:
        record = CourseTable.objects.get(pk=id,adviser=request.user)
        exam = examTable.objects.get(pk = examid,course = record) 
        #Submitted Form
        if request.method == "POST":
            try:
                if request.POST["delete"] == "delete":
                    question = QuestionTable.objects.get(pk = request.POST["row"])
                    question.delete()
                    return HttpResponse("Success")
            except:
                return HttpResponse("Invalid")
                
        #End of Submitted Form
        list_ = []
        if action =="multipleChoice":
            question = QuestionTable.objects.filter(exam = exam).exclude(type__in=["trueorfalse","identification"])
            for item_ in question:
                list_.append([item_.id,item_.question,item_.answer,item_.choice1,item_.choice2,item_.choice3,item_.choice4,])
            return JsonResponse(list_,safe=False)
        elif action == "trueorfalse":
            question = QuestionTable.objects.filter(exam = exam,type="trueorfalse")
            for item_ in question:
                list_.append([item_.id,item_.question,item_.answer])
            return JsonResponse(list_,safe=False)
        elif action == "identification":
            question = QuestionTable.objects.filter(exam = exam,type="identification")
            for item_ in question:
                list_.append([item_.id,item_.question,item_.answer])
            return JsonResponse(list_,safe=False)
    except:
        return HttpResponse("Record not found")

def students(request,id):
    course = CourseTable.objects.get(pk=id)
    if request.method == "POST":
        if request.POST["action"] == "add":
            list = request.POST["list"]
            list = list.split(",")
            test = []
            for item in list:
                if item != "":
                    studentData = Users.objects.get(pk = item)
                    examStudentListTable.objects.create(course=course,registered = studentData,date_created = datetime.now())
    registeredStudent = examStudentListTable.objects.filter(course = course)
    x = []
    for list in registeredStudent:
        try:
            i = list.registered.id
            x.append(i)
        except:
            pass
    student = Users.objects.exclude(pk__in=x)
    return render(request,"managestudent.html",{
        "registeredStudent":registeredStudent,
        "student":student,
        "record":course
    })



def login_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse(index))
    if(request.method == "POST"):
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request,"index.html",{
                "xmessage":"Invalid Credentials",
                "message":"notfound",  
                "tracking":"",  
            })
    else:
        return render(request,"index.html")

def logout_view(request):
    logout(request)
    return render(request,"index.html",{
    })
# Create your views here.
def makepass(request,pass_):

    try:
        return JsonResponse([pass_],safe=False)
    except:
        return HttpResponse("Invalid")

def registerUser(request):
    try:
        user = User.objects.create_user(request.GET["username"],'',request.GET["password"])
        user.first_name = request.GET["first_name"]
        user.last_name = request.GET["last_name"]
        user.save()
        return HttpResponseRedirect('http://127.0.0.1:3001/')
    except:
        return HttpResponse("Invalid")
    