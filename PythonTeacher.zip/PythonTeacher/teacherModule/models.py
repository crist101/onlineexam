from django.db import models
from django.contrib.auth.models import User

class CourseTable(models.Model):
    course_name = models.CharField(max_length=1000)
    adviser = models.ForeignKey(User,on_delete=models.DO_NOTHING,related_name="Adviser",null=True)
    course_date_created = models.DateTimeField()

    def __str__(self):
        return self.course_name
    

class examTable(models.Model):
    course = models.ForeignKey(CourseTable, on_delete=models.CASCADE)
    exam_title = models.CharField(max_length=1000)
    startOfExam = models.DateTimeField(null=True)
    endOfExam = models.DateTimeField(null=True)
    exam_description = models.CharField(max_length=1000)
    date_created = models.DateTimeField()
    exam_status = models.CharField(max_length=1000,null=True)

    def __str__(self):
        return f"{self.exam_title}"
  
class QuestionTable(models.Model):
    exam = models.ForeignKey(examTable, on_delete=models.CASCADE)
    question = models.TextField()
    choice1 = models.CharField(max_length=1000,null=True)
    choice2 = models.CharField(max_length=1000,null=True)
    choice3 = models.CharField(max_length=1000,null=True)
    choice4 = models.CharField(max_length=1000,null = True)
    answer = models.CharField(max_length=1000)
    type = models.CharField(max_length=50,null=True)
    
    
    def __str__(self):
        return f"Exam: {self.exam}|{self.question} | Answer: {self.answer}"

class Users(models.Model):
    name = models.CharField(max_length=255)
    email = models.CharField(unique=True, max_length=255)
    email_verified_at = models.DateTimeField(blank=True, null=True)
    password = models.CharField(max_length=255)
    remember_token = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'users'
        
    def __str__(self):
        return f"{self.name}"
    
class examStudentListTable(models.Model):
    course = models.ForeignKey(CourseTable,models.DO_NOTHING)
    registered = models.ForeignKey(Users,models.DO_NOTHING)
    date_created = models.DateTimeField()

    def __str__(self):
        return f"{self.registered}"
    
class studentExamFormTable(models.Model):
    exam = models.ForeignKey(examTable,null = True, related_name="studentexam", on_delete=models.CASCADE)
    form = models.ForeignKey(examStudentListTable,null = True, related_name="studentform", on_delete=models.CASCADE)
    score = models.IntegerField(default = 0)
    status = models.CharField(blank=True, max_length=200)
    def __str__(self):
        return f"{self.form.registered.name}"
    
class studentAnswerKey(models.Model):
    keyid = models.AutoField(primary_key=True)
    studentExamFormTable = models.ForeignKey(studentExamFormTable, related_name="answerKey", on_delete=models.CASCADE)
    answer = models.CharField(blank=True, max_length=50)
    question = models.ForeignKey(QuestionTable,null=True, related_name="questionKey", on_delete=models.CASCADE)
    
    def __str__(self):
        return f"{self.studentExamFormTable}"
        

        
