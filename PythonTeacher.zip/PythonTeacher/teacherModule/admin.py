from django.contrib import admin
from .models import CourseTable,examTable,QuestionTable,Users,examStudentListTable,studentExamFormTable,studentAnswerKey

admin.site.register(CourseTable)
admin.site.register(examTable)
admin.site.register(QuestionTable)
admin.site.register(Users)
admin.site.register(examStudentListTable)
admin.site.register(studentExamFormTable)
admin.site.register(studentAnswerKey)


# Register your models here.
