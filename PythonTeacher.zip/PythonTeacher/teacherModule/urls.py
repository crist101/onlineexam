"""onlineExam URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from . import views
from django.urls import path

urlpatterns = [
    path("", views.index ,name="index"),
    path("login",views.login_view,name="login"),
    path("logout",views.logout_view,name="logout"),
    path("home",views.home,name="home"),
    path("home/course/<int:id>",views.course,name="course"),
    path("home/course/<int:id>/courseArchived",views.courseArchived,name="courseArchived"),
    path("home/course/<int:id>/Restore",views.courseRestore,name="courseRestore"),
    path("home/course/<int:id>/update",views.courseUpdate,name="courseUpdate"),
    path("home/course/<int:id>/<int:examid>/action",views.courseAction,name="courseAction"),
    path("home/course/<int:id>/exam/<int:examid>",views.examForm,name="examForm"),
    path("home/course/<int:id>/exam/<int:examid>/result",views.examFormResult,name="examFormResult"),
    path("home/course/exam/result/<int:examid>/return",views.getAnswerSheet,name="getAnswerSheet"),
    path("home/course/<int:id>/exam/<int:examid>/list/<slug:action>",views.examFormList,name="examFormList"),
    path("home/course/exam/list/ediForm",views.editForm,name="editForm"),
    path("home/course/<int:id>/students",views.students,name="students"),
    path("generatepassword/<slug:pass_>", views.makepass ,name="makepass"),
    path("registerUser", views.registerUser ,name="registerUser"),
]
