from django.contrib import admin
#from .models import CourseTable,examTable,QuestionTable,Users

#admin.site.register(CourseTable)
#admin.site.register(examTable)
#admin.site.register(QuestionTable)
#admin.site.register(Users)
# Register your models here.
