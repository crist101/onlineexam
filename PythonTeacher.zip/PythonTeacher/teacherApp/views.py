from django.shortcuts import render
from django.http import HttpResponse,JsonResponse,HttpResponseRedirect
#from .models import Users
# Create your views here.

def index(request):
    return render(request,"login.html")


#def student(request):
    #student = Users.objects.get(pk=1)
    #return HttpResponse(student.name)