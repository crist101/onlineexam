const mysql = require("mysql");
const bcrypt = require('bcrypt');

// Connection
let connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

// view users
  exports.view = (req, res) => {
    res.render("onepage");
  };


//Get Student List
exports.listStudent = (req, res) => {
  connection.connect(function(err) {
      connection.query("SELECT * FROM users", function (err, result, fields) {
        if (!err) {
          res.json(result)
        }
      });
  });
}

////Get Teacher List
exports.listTeacher = (req, res) => {
  connection.connect(function(err) {
      connection.query("SELECT * FROM auth_user", function (err, result, fields) {
          if (!err) {
            res.json(result)
          }
      });
  });
}


exports.updateTeacher = (req,res)=>{
  const {
    id,
    val,
    col
  } = req.body;
  
  connection.query(
    "UPDATE auth_user SET "+col+" = '"+val+"' where id = "+id,
    (err, rows) => {
      if (!err) {
        res.json(["Success"])
      } else {
        res.json(["Invalid"])
      }
    }
  );
}

exports.deleteTeacher = (req,res) =>{
  const {
    id,
  } = req.body;
  connection.query(
    "DELETE FROM auth_user WHERE id = ?",
    [id],
    (err, rows) => {
      if (!err) {
        let removedUser = encodeURIComponent("User successeflly removed.");
        res.render("onepage");
      } else {
        console.log(err);
      }
    }
  );
}

//Code for Student
const hashPassword = async (password, saltRounds = 10) => {
  try {
    // Generate a salt
    const salt = await bcrypt.genSalt(saltRounds)

    // Hash password
    return await bcrypt.hash(password, salt)
  } catch (error) {
    console.log(error)
  }

  // Return null if error
  return null
}

exports.addStudent = async (req,res)=>{
  const {
    name,
    email,
    password,
  } = req.body;
  let searchTerm = req.body.search;

  const hash = await hashPassword(password)
  // User the connection
  connection.query(
    "INSERT INTO users SET email = ?, name = ?, password = ?",
    [
      email,
      name,
      hash,
    ],
    (err, rows) => {
      if (!err) {
        res.json(["Success"])
      } else {
        res.json(["Invalid"])
        console.log(err);
      }
    }
  );
}

exports.deleteStudent = (req,res) =>{
  const {
    id,
  } = req.body;
  connection.query(
    "DELETE FROM users WHERE id = ?",
    [id],
    (err, rows) => {
      if (!err) {
        let removedUser = encodeURIComponent("User successeflly removed.");
        res.json(["Success"])
      } else {
        res.json(["Invalid"])
      }
    }
  );
}
exports.updateStudent = (req,res)=>{
  const {
    id,
    val,
    col
  } = req.body;
  
  connection.query(
    "UPDATE users SET "+col+" = '"+val+"' where id = "+id,
    (err, rows) => {
      if (!err) {
        res.json(["Success"])
      } else {
        res.json(["Invalid"])
      }
    }
  );
}
/*
// Find User by Search
exports.find = (req, res) => {
  let searchTerm = req.body.search;
  // User the connection
  connection.query(
    "SELECT * FROM user WHERE first_name LIKE ? OR last_name LIKE ?",
    ["%" + searchTerm + "%", "%" + searchTerm + "%"],
    (err, rows) => {
      if (!err) {
        res.render("home", { rows });
      } else {
        console.log(err);
      }
      console.log("The data from user table: \n", rows);
    }
  );
};

exports.form = (req, res) => {
  res.render("addUser");
};

// Add new user
exports.create = (req, res) => {
  const {
    first_name,
    last_name,
    midle_name,
    user_name,
    password,
    created_by,
    account_type,
  } = req.body;
  let searchTerm = req.body.search;

  // User the connection
  connection.query(
    "INSERT INTO user SET first_name = ?, last_name = ?, midle_name = ?, user_name = ?, password = ?, created_by = ?, account_type = ?",
    [
      first_name,
      last_name,
      midle_name,
      user_name,
      password,
      created_by,
      account_type,
    ],
    (err, rows) => {
      if (!err) {
        res.render("addUser", { alert: "User added successfully." });
      } else {
        console.log(err);
      }
      console.log("The data from user table: \n", rows);
    }
  );
};

// Edit user
exports.edit = (req, res) => {
  // User the connection
  connection.query(
    "SELECT * FROM user WHERE id = ?",
    [req.params.id],
    (err, rows) => {
      if (!err) {
        res.render("edit-user", { rows });
      } else {
        console.log(err);
      }
      console.log("The data from user table: \n", rows);
    }
  );
};

// Update User
exports.update = (req, res) => {
  const {
    first_name,
    last_name,
    midle_name,
    user_name,
    password,
    created_by,
    account_type,
  } = req.body;
  // User the connection
  connection.query(
    "UPDATE user SET first_name = ?, last_name = ?, midle_name = ?, user_name = ?, password = ?, created_by = ?, account_type = ? WHERE id = ?",
    [
      first_name,
      last_name,
      midle_name,
      user_name,
      password,
      created_by,
      account_type,
      req.params.id,
    ],
    (err, rows) => {
      if (!err) {
        // User the connection
        connection.query(
          "SELECT * FROM user WHERE id = ?",
          [req.params.id],
          (err, rows) => {
            // When done with the connection, release it

            if (!err) {
              res.render("edit-user", {
                rows,
                alert: `${first_name} has been updated.`,
              });
            } else {
              console.log(err);
            }
            console.log("The data from user table: \n", rows);
          }
        );
      } else {
        console.log(err);
      }
      console.log("The data from user table: \n", rows);
    }
  );
};

// Delete User
exports.delete = (req, res) => {
  connection.query(
    "DELETE FROM user WHERE id = ?",
    [req.params.id],
    (err, rows) => {
      if (!err) {
        let removedUser = encodeURIComponent("User successeflly removed.");
        res.redirect("/?removed=" + removedUser);
      } else {
        console.log(err);
      }
      console.log("The data from beer table are: \n", rows);
    }
  );
};
*/