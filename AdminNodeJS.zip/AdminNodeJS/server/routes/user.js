const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");

  
router.get("/", userController.view);
router.get("/listStudent", userController.listStudent);
router.get("/listTeacher", userController.listTeacher);
router.post("/deleteTeacher", userController.deleteTeacher);
router.post("/updateTeacher", userController.updateTeacher);
router.post("/addStudent", userController.addStudent);
router.post("/deleteStudent", userController.deleteStudent);
router.post("/updateStudent", userController.updateStudent);

module.exports = router;
