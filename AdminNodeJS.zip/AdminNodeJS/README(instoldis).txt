npm install express dotenv express-handlebars body-parser mysql

nmp install --save-dev nodemon